# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
DogGroomer::Application.config.secret_token = '0e43c840c3e0bfb127528c04d38c6ec6584c7f5e1706d65c01d15174ecae2aad3e35f731a7aa8f57a319844bcb702d8029e505d079458a3d53c5ecd3c299b768'
