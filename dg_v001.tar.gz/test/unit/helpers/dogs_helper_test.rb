require 'test_helper'

class DogsHelperTest < ActionView::TestCase
end
