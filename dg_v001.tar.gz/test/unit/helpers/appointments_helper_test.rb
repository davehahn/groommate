require 'test_helper'

class AppointmentsHelperTest < ActionView::TestCase
end
