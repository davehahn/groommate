class Appointment < ActiveRecord::Base  

  belongs_to :dog
  

end
